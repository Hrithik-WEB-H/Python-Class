class CustomError(Exception):
  pass

try:
    raise CustomError("This is a custom error!")
except CustomError as e:
    print(e)
