file = open('example.txt', 'r')
file.close()
