with open('shoping_list.txt', 'w') as file:
  for item in items:
        file.write(f"{item}\n")
print("Shopping list created and written to shopping_list.txt.")
