print("Hello Rittik")
