class JafriCode:
 def __init__(self):
  print("It is constructor")
  
obj = JafriCode()
