with open('output.txt', 'w') as file:
  file.write('Hello, World!\n')
