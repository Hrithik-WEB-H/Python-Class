class Jafri:
  JafriId = 122
  JafriName = "Hrithik"
  
  def showId(self):
   print("ID:", self.JafriId)
  
obj = Jafri()
print("Name", obj.JafriName)
obj.showId()
